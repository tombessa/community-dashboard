from contextlib import closing
import sqlite3
import pandas as pd
from github import Github, RateLimitExceededException
import streamlit as st

from src.job.help_db import DB_PATH, save_github_item, start_sync, finish_sync, fail_sync


def get_github_client():
    """
    Fetches the token from secrets.toml and initializes
    the GitHub client. Streamlit automatically searches
    within .streamlit/secrets.toml.
    """
    token = st.secrets.get("GITHUB_TOKEN", None)
    if token:
        return Github(token)
    # Fallback to unauthenticated client (lower rate limits)
    return Github()

def synchronize_repository(repo_name):
    started_at, since = start_sync(repo_name)

    try:
        total = sync_repo_data(
            repo_name=repo_name,
            since=since,
        )

        # Executes only after all transactions
        finish_sync(repo_name, started_at)

    except Exception as error:
        fail_sync(repo_name, error)
        raise

    return total

def sync_repo_data(repo_name: str, since=None):
    """
    Search date on GitHub and store at SQLite
    Busca dados no GitHub e grava no SQLite.

    since=None: full data payload
    since=datetime UTC: payload items updated only at this day.

    Returns qtd updated items.
    """
    g = get_github_client()

    try:
        repo = g.get_repo(repo_name)

        filters = {
            "state": "all",
            "sort": "updated",
            "direction": "asc",
        }

        if since is not None:
            filters["since"] = since

        processed = 0

        with closing(
                sqlite3.connect(DB_PATH, timeout=30)
        ) as conn:
            for issue in repo.get_issues(**filters):
                base_info = {
                    "id": issue.id,
                    "number": issue.number,
                    "title": issue.title,
                    "created_at": issue.created_at,
                    "closed_at": issue.closed_at,
                    "labels": [
                        label.name for label in issue.labels
                    ],
                    "assignee": (
                        issue.assignee.login
                        if issue.assignee
                        else None
                    ),
                    "author": (
                        issue.user.login
                        if issue.user
                        else "Unknown"
                    ),
                    "avatar_url": (
                        issue.user.avatar_url
                        if issue.user
                        else "https://github.com"
                    ),
                }

                if issue.pull_request:
                    pr = repo.get_pull(issue.number)

                    base_info["merged_at"] = pr.merged_at
                    base_info["is_merged"] = pr.merged

                else:
                    first_comment = next(
                        iter(issue.get_comments()), None
                    )

                    base_info["first_response_at"] = (
                        first_comment.created_at
                        if first_comment
                        else None
                    )

                save_github_item(
                    conn, repo_name, issue, base_info
                )

                processed += 1

        return processed

    finally:
        g.close()