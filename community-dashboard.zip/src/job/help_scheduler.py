import argparse
import logging
import os
from datetime import datetime
from pathlib import Path

from src.job.github_async import synchronize_repository

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(
        description="Synchronize GitHub repository data into SQLite."
    )
    parser.add_argument(
        "--repository",
        default="scanapi/scanapi",
        help="GitHub repository in owner/name format.",
    )
    args = parser.parse_args()

    # Use the project root as the working directory so that
    # Streamlit can locate .streamlit/secrets.toml.
    os.chdir(PROJECT_ROOT)

    logs_dir = PROJECT_ROOT / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)

    # Append execution logs to a daily log file.
    log_file = logs_dir / f"sync_{datetime.now():%Y-%m-%d}.log"

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[
            logging.FileHandler(log_file, encoding="utf-8"),
            logging.StreamHandler(),
        ],
    )

    try:
        # Import after configuring the working directory and logging.

        logging.info(
            "Starting synchronization: %s",
            args.repository,
        )

        total = synchronize_repository(args.repository)

        logging.info(
            "Synchronization completed: repository=%s, items=%s",
            args.repository,
            total,
        )

        # Report successful execution to the task scheduler.
        return 0

    except Exception:
        # Record the traceback and report failure to the task scheduler.
        logging.exception(
            "Synchronization failed: %s",
            args.repository,
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())